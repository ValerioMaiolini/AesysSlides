package org.spring.orchestra.models;

public interface Instrument {
  void playInstrument();
}
