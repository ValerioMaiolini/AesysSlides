package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Piano extends AbstractInstrument {
  public Piano() { super("Piano"); }
}
