package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Trumpet extends AbstractInstrument {
  public Trumpet() { super("Trumpet"); }
}
