package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Flute extends AbstractInstrument {
  public Flute() { super("Flute"); }
}
