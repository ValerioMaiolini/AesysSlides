package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Percussion extends AbstractInstrument {
  protected Percussion() {
    super("Percussion");
  }
}
