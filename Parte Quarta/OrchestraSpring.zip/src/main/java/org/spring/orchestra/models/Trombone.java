package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Trombone extends AbstractInstrument {
  public Trombone() { super("Trombone"); }
}
