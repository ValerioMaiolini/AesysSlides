package org.spring.orchestra.models;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Scope("prototype")
public class Musician {
  private final Instrument instrument;

  public Instrument getInstrument() {
    return this.instrument;
  }

  public Musician(Instrument instr) {
    this.instrument = instr;
  }

  public void play() {
    this.instrument.playInstrument();
  }

  @PostConstruct
  public void sayHello() {
    System.out.println("Hello, I'm the musician: " + this);
    System.out.println("I'm going to play " + this.instrument + " instrument");
    System.out.println(" ----------");
  }
}
