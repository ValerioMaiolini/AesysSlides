package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Viola extends AbstractInstrument {
  public Viola() { super("Viola"); }
}
