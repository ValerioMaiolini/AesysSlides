package org.spring.orchestra.service;

import org.spring.orchestra.models.Instrument;
import org.spring.orchestra.models.Musician;
import org.spring.orchestra.models.Viola;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ConductorService {
  @Autowired
  private ApplicationContext ctx;
  @Autowired
  private List<Instrument> instruments;
  private List<Musician> musicians;

  public void playOrchestra() {
    this.musicians = new ArrayList<>(this.instruments.size());

    Musician m;
    for (Instrument i : this.instruments) {
      m = ctx.getBean(Musician.class, i);
      this.musicians.add(m);
    }

    System.out.println(" // ********************* //");
    this.musicians.parallelStream().forEach(x -> x.play());
    System.out.println(" // ********************* //");

    Instrument viola = ctx.getBean(Viola.class);
    Musician violaMusician = ctx.getBean(Musician.class, viola);
    violaMusician.play();
  }
}
