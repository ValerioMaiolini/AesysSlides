package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Clarinet extends AbstractInstrument {
  public Clarinet() { super("Clarinet"); }

  @Override
  public void playInstrument() {
    System.out.println("I refuse to play clarinet!!");
  }
}
