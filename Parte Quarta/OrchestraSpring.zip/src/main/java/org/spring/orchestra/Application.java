package org.spring.orchestra;

import org.spring.orchestra.service.ConductorService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Application {

  public static void main(String[] args) {
    ApplicationContext ctx = new AnnotationConfigApplicationContext("org.spring.orchestra.service", "org.spring.orchestra.models");
    ConductorService service = ctx.getBean(ConductorService.class);
    service.playOrchestra();
  }
}
