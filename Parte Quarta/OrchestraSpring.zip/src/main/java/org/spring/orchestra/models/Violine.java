package org.spring.orchestra.models;

import org.springframework.stereotype.Component;

@Component
public class Violine extends AbstractInstrument {
  public Violine() { super("Violine"); }
}
