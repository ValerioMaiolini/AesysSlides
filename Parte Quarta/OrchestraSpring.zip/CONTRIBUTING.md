# Contributing to spraybot

When contributing to any spraybot project you should follow the general
guidelines described at `CONTRIBUTING.md` in the [spraybot/contributing
repository](https://github.com/spraybot/contributing). Library specific
guidelines are detailed below.