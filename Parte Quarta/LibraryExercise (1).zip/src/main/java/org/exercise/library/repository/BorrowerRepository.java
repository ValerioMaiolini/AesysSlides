package org.exercise.library.repository;

import org.exercise.library.models.Borrower;
import org.springframework.stereotype.Repository;

@Repository
public class BorrowerRepository extends AbstractRepo<Borrower> {

    public BorrowerRepository() {
        super();
        this.add(new Borrower("Mario", "Rossi"));
        this.add(new Borrower("Giuseppe", "Verdi"));
    }
}
