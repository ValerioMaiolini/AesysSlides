package org.exercise.library.models;

public abstract class AbstractEntity {
    private Integer id;

    protected AbstractEntity() { this.id = null; }
    protected AbstractEntity(Integer id) { this.id = id; }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
