package org.exercise.library.repository;

import org.exercise.library.models.Reservation;
import org.springframework.stereotype.Repository;

@Repository
public class ReservationRepository extends AbstractRepo<Reservation> {

    public ReservationRepository() {
        super();
    }
}
