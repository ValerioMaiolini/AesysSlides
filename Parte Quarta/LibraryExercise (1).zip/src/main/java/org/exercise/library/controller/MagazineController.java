package org.exercise.library.controller;

import org.exercise.library.models.Magazine;
import org.exercise.library.service.MagazineService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/magazine")
public class MagazineController {
    private final MagazineService service;

    public MagazineController(MagazineService magazineService) {
        this.service = magazineService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Magazine>> findAllMagazines() {
        List<Magazine> response = service.findMagazines();
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<Magazine> getMagazine(@PathVariable Integer id) {
        Magazine response = service.getMagazine(id);
        return ResponseEntity.ok(response);
    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<Magazine> addMagazine(@RequestBody Magazine newMagazine) {
        Magazine response = service.addMagazine(newMagazine);
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deleteMagazine(@PathVariable Integer id) {
        service.deleteMagazine(id);
        return ResponseEntity.noContent().build();
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Magazine> updateMagazine(@PathVariable Integer id, @RequestBody Magazine updatedMagazine) {
        Magazine response = service.updateMagazine(id, updatedMagazine);
        return ResponseEntity.ok(response);
    }
}
