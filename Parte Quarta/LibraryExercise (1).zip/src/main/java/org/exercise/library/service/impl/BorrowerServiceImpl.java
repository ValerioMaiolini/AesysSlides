package org.exercise.library.service.impl;

import org.exercise.library.models.Book;
import org.exercise.library.models.Borrower;
import org.exercise.library.models.Magazine;
import org.exercise.library.repository.GenericRepo;
import org.exercise.library.service.BorrowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class BorrowerServiceImpl implements BorrowerService {
    private final GenericRepo<Borrower> repo;
    private final GenericRepo<Book> bookRepo;
    private final GenericRepo<Magazine> magazineRepo;

    @Autowired
    public BorrowerServiceImpl(
            GenericRepo<Borrower> repository,
            GenericRepo<Book> bookRepository,
            GenericRepo<Magazine> magazineRepository
    ) {
        this.repo = repository;
        this.bookRepo = bookRepository;
        this.magazineRepo = magazineRepository;
    }

    @Override
    public Borrower getBorrower(int id) {
        return repo.getById(id);
    }

    @Override
    public List<Borrower> findBorrower() {
        return repo.findAll();
    }

    @Override
    public Borrower addBorrower(Borrower newBorrower) {
        return repo.add(newBorrower);
    }

    @Override
    public void deleteBorrower(int id) {
        repo.delete(id);
    }

    @Override
    public Borrower updateBorrower(int id, Borrower updated) {
        return repo.update(id, updated);
    }

    @Override
    public boolean canBorrow(int borrowerId, List<Integer> bookIds, List<Integer> magazineIds) {
        Borrower existingBorrower = repo.getById(borrowerId);
        if (existingBorrower == null)
            return false;

        if (!CollectionUtils.isEmpty(bookIds)) {
            Book existingBook;
            for (Integer bookId : bookIds) {
                existingBook = bookRepo.getById(bookId);
                if (existingBook == null)
                    return false;
            }
        }

        if (!CollectionUtils.isEmpty(magazineIds)) {
            Magazine existingMagazine;
            for (Integer magazineId : magazineIds) {
                existingMagazine = magazineRepo.getById(magazineId);
                if (existingMagazine == null)
                    return false;
            }
        }

        return true;
    }
}
