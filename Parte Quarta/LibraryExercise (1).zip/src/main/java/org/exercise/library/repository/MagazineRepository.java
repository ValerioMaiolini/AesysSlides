package org.exercise.library.repository;

import org.exercise.library.models.Magazine;
import org.springframework.stereotype.Repository;

@Repository
public class MagazineRepository extends AbstractRepo<Magazine> {

    public MagazineRepository() {
        super();
        this.add(new Magazine("Wired"));
        this.add(new Magazine("Focus"));
        this.add(new Magazine("Cosmopolitan"));
        this.add(new Magazine("Time"));
    }
}
