package org.exercise.library.controller;

import org.exercise.library.models.Borrower;
import org.exercise.library.service.BorrowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/borrower")
public class BorrowerController {
    private final BorrowerService service;

    @Autowired
    public BorrowerController(BorrowerService borrowerService) {
        this.service = borrowerService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Borrower>> findAllBorrowers() {
        List<Borrower> response = service.findBorrower();
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<Borrower> getBorrower(@PathVariable Integer id) {
        Borrower response = service.getBorrower(id);
        return ResponseEntity.ok(response);
    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<Borrower> addBorrower(@RequestBody Borrower newBorrower) {
        Borrower response = service.addBorrower(newBorrower);
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> deleteBorrower(@PathVariable Integer id) {
        service.deleteBorrower(id);
        return ResponseEntity.noContent().build();
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Borrower> updateBorrower(Integer id, Borrower updatedBorrower) {
        Borrower response = service.updateBorrower(id, updatedBorrower);
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/canborrow", method = RequestMethod.GET)
    public ResponseEntity<Boolean> canBorrow(
            @RequestParam(value = "borrowerId") Integer borrowerId,
            @RequestParam(value = "booksIds", required = false) List<Integer> booksIds,
            @RequestParam(value = "magazineIds", required = false) List<Integer> magazineIds
    ) {
        boolean canBorrow = service.canBorrow(borrowerId, booksIds, magazineIds);
        return ResponseEntity.ok(canBorrow);
    }
}
