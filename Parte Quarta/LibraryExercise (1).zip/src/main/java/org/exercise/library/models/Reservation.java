package org.exercise.library.models;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import java.util.Date;
import java.util.List;

public class Reservation extends AbstractEntity {
    @JsonFormat(shape = Shape.STRING, pattern = "dd/MM/yyyy")
    private Date creationDate;
    private Integer borrowerId;
    private List<Integer> bookIds;
    private List<Integer> magazineIds;

    public Reservation() {
        super();
        this.creationDate = new Date();
    }
    public Reservation(Integer borrowerId, List<Integer> bookIds, List<Integer> magazineIds) {
        super();
        this.creationDate = new Date();
        this.borrowerId = borrowerId;
        this.bookIds = bookIds;
        this.magazineIds = magazineIds;
    }
    public Reservation(Integer id, Integer borrowerId, List<Integer> bookIds, List<Integer> magazineIds) {
        super(id);
        this.creationDate = new Date();
        this.borrowerId = borrowerId;
        this.bookIds = bookIds;
        this.magazineIds = magazineIds;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Integer getBorrowerId() {
        return borrowerId;
    }

    public void setBorrowerId(Integer borrowerId) {
        this.borrowerId = borrowerId;
    }

    public List<Integer> getBookIds() {
        return bookIds;
    }

    public void setBookIds(List<Integer> bookIds) {
        this.bookIds = bookIds;
    }

    public List<Integer> getMagazineIds() {
        return magazineIds;
    }

    public void setMagazineIds(List<Integer> magazineIds) {
        this.magazineIds = magazineIds;
    }
}
