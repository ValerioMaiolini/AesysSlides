package org.exercise.library.repository;

import org.exercise.library.models.AbstractEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class AbstractRepo<E extends AbstractEntity> implements GenericRepo<E> {
    protected final List<E> mockedDb;
    private static final AtomicInteger sequence = new AtomicInteger(0);

    protected AbstractRepo() {
        this.mockedDb = new ArrayList<>();
    }

    @Override
    public E getById(int id) {
        return this.mockedDb.stream()
                .filter(b -> id == b.getId())
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<E> findAll() {
        return this.mockedDb;
    }

    @Override
    public E add(E entity) {
        Integer newId = sequence.incrementAndGet();
        entity.setId(newId);

        this.mockedDb.add(entity);

        return entity;
    }

    @Override
    public void delete(int id) {
        this.mockedDb.stream()
                .filter(b -> id == b.getId())
                .findFirst()
                .ifPresent(x -> this.mockedDb.remove(x));
    }

    @Override
    public E update(int id, E updated) {
        E found = getById(id);

        if (found != null) {
            int idx = this.mockedDb.indexOf(found);

            updated.setId(found.getId());
            this.mockedDb.set(idx, updated);

            return updated;
        } else
            throw new IllegalStateException("No entity with " + id + " id found");
    }
}
